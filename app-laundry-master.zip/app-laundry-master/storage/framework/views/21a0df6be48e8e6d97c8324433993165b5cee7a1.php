<!DOCTYPE html>
<html lang="en">

<head>
    <title>Laporan Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <style>

    </style>
</head>

<body>

    <header class="text-center">
        <div class="row">
            <div class="col-4">
                <h1><?php echo e(config('app.name')); ?></h1>
            </div>
            <div class="col-4">
                <h3>Laporan Transaksi Bulan <?php echo e($monthInput); ?> Tahun <?php echo e($yearInput); ?></h3>
            </div>
            <div class="col-4">
            </div>
        </div>
    </header>
    <hr>
    <main>
        <p>Banyak transaksi: <?php echo e($transactionsCount); ?> transaksi</p>
        <p>Total pendapatan: Rp <?php echo e(number_format($revenue, 0, ',', '.')); ?></p>
    </main>
    <hr>
    <footer class="text-end">
        <span class="text-muted small text-end">Dicetak pada <?php echo e(date('d M Y')); ?></span>
    </footer>

</body>

</html>
<?php /**PATH D:\XASMP\htdocs\app-laundry-crud\app-laundry-master\resources\views/admin/report_pdf.blade.php ENDPATH**/ ?>