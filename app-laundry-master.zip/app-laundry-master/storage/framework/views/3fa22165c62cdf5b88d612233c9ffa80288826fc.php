<?php $__env->startSection('main-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Saran atau Komplain</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php elseif(session('warning')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?php echo e(session('warning')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <form action="<?php echo e(route('member.complaints.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <h5>Silahkan isi form dibawah ini sesuai kriteria</h5>
                                        <div class="form-group">
                                            <select class="form-control" id="tipe" name="type">
                                                <option value="1">Saran</option>
                                                <option value="2">Komplain</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <textarea class="form-control" id="form_sarankomplain" rows="4" name="body"></textarea>
                                        </div>
                                        <button class="btn btn-primary badge-pill float-right w-25"
                                            type="submit">Kirim</button>
                                    </form>
                                </div>
                                <div class="col-md-6">
                                    <h5>Telepon atau Chat:</h5>
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td>Line</td>
                                                <td>@idline</td>
                                            </tr>
                                            <tr>
                                                <td>Whatsapp</td>
                                                <td>081999999</td>
                                            </tr>
                                            <tr>
                                                <td>Telepon</td>
                                                <td>(0361)123456</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Ketentuan: Hanya melayani saat jam kerja</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5>Riwayat Saran atau Komplain</h5>
                            <table class="table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Tipe</th>
                                        <th>Isi</th>
                                        <th>Balasan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $complaintSuggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaintSuggestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($complaintSuggestion->created_at))); ?></td>
                                            <td>
                                                <?php if($complaintSuggestion->type == 1): ?>
                                                    Saran
                                                <?php else: ?>
                                                    Komplain
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($complaintSuggestion->body); ?></td>
                                            <?php if($complaintSuggestion->reply == null): ?>
                                                <td class="text-danger">
                                                    Belum ada balasan
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <?php echo e($complaintSuggestion->reply); ?>

                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app-laundry-master\resources\views/member/complaint_suggestions.blade.php ENDPATH**/ ?>