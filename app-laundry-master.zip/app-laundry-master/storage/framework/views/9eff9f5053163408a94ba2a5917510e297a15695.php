<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('vendor/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Detail Transaksi</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h3>ID Transaksi: <?php echo e($id); ?></h3>
                            <hr>
                            <table id="tbl-detail" class="table dataTable dt-responsive nowrap" style="width:100%">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Barang</th>
                                        <th>Kategori</th>
                                        <th>Servis</th>
                                        <th>Banyak</th>
                                        <th>Harga</th>
                                        <th>Sub Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($transaction->price_list->item->name); ?></td>
                                            <td><?php echo e($transaction->price_list->category->name); ?></td>
                                            <td><?php echo e($transaction->price_list->service->name); ?></td>
                                            <td><?php echo e($transaction->quantity); ?></td>
                                            <td><?php echo e($transaction->getFormattedPrice()); ?></td>
                                            <td><?php echo e($transaction->getFormattedSubTotal()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr>
                            <h5>Tipe Servis: <?php echo e($transactions[0]->transaction->service_type->name); ?></h5>
                            <h5>Biaya Servis: <?php echo e($transactions[0]->transaction->getFormattedServiceCost()); ?></h5>
                            <h5>Potongan: <?php echo e($transactions[0]->transaction->discount); ?></h5>
                            <hr>
                            <h4>Total Biaya: <?php echo e($transactions[0]->transaction->getFormattedTotal()); ?></h4>
                            <h4>Dibayar: <?php echo e($transactions[0]->transaction->getFormattedPaymentAmount()); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#tbl-detail').DataTable({
                "searching": false,
                "bPaginate": false,
                "bLengthChange": false,
                "bFilter": false,
                "bInfo": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XASMP\htdocs\app-laundry-crud\app-laundry-master\resources\views/member/detail.blade.php ENDPATH**/ ?>