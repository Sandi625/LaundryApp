<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="base_url" content="<?php echo e(url('admin')); ?>">
    <link href="<?php echo e(asset('vendor/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Riwayat Transaksi</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="" method="get">
                                <div class="form-group row">
                                    <label for="tahun" class="col-auto col-form-label">Tahun</label>
                                    <div class="col-auto">
                                        <select class="form-control" id="tahun" name="year">
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($year->tahun == $currentYear): ?>
                                                    <option value="<?php echo e($year->Tahun); ?>" selected><?php echo e($year->Tahun); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($year->Tahun); ?>"><?php echo e($year->Tahun); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <label for="bulan" class="col-auto col-form-label">Bulan</label>
                                    <div class="col-auto">
                                        <select class="form-control" id="bulan" name="month">
                                            <?php for($i = 1; $i <= 12; $i++): ?>
                                                <?php if($i == $currentMonth): ?>
                                                    <option value="<?php echo e($i); ?>" selected>
                                                        <?php echo e($i); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" id="btn-filter" class="btn btn-primary">Filter</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3">Transaksi Berjalan (Priority Service)</h4>
                            <table id="tbl-transaksi-priority" class="table dt-responsive nowrap" style="width: 100%">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID Transaksi</th>
                                        <th>Tanggal</th>
                                        <th>Nama Member</th>
                                        <th>Status</th>
                                        <th>Biaya Service</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ongoingPriorityTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->member->name); ?></td>
                                            <td>
                                                <?php if($item->status_id == 3): ?>
                                                    <span class="text-success">Selesai</span>
                                                <?php else: ?>
                                                    <select name="" id="status" data-id="<?php echo e($item->id); ?>"
                                                        data-val="<?php echo e($item->status_id); ?>" class="select-status">
                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($item->status_id == $s->id): ?>
                                                                <option selected value="<?php echo e($s->id); ?>">
                                                                    <?php echo e($s->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->getFormattedServiceCost()); ?></td>
                                            <td><?php echo e($item->getFormattedTotal()); ?></td>
                                            <td>
                                                <a href="#" class="badge badge-info btn-detail" data-toggle="modal"
                                                    data-target="#transactionDetailModal"
                                                    data-id="<?php echo e($item->id); ?>">Detail</a>
                                                <a href="<?php echo e(route('admin.transactions.print.index', ['transaction' => $item->id])); ?>"
                                                    class="badge badge-primary" target="_blank">Cetak</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3">Transaksi Berjalan</h4>
                            <table id="tbl-transaksi-belum" class="table dt-responsive nowrap" style="width: 100%">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID Transaksi</th>
                                        <th>Tanggal</th>
                                        <th>Nama Member</th>
                                        <th>Status</th>
                                        <th>Biaya Service</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ongoingTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->member->name); ?></td>
                                            <td>
                                                <?php if($item->status_id == 3): ?>
                                                    <span class="text-success">Selesai</span>
                                                <?php else: ?>
                                                    <select name="" id="status" data-id="<?php echo e($item->id); ?>"
                                                        data-val="<?php echo e($item->status_id); ?>" class="select-status">
                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($item->status_id == $s->id): ?>
                                                                <option selected value="<?php echo e($s->id); ?>">
                                                                    <?php echo e($s->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->getFormattedServiceCost()); ?></td>
                                            <td><?php echo e($item->getFormattedTotal()); ?></td>
                                            <td>
                                                <a href="#" class="badge badge-info btn-detail" data-toggle="modal"
                                                    data-target="#transactionDetailModal"
                                                    data-id="<?php echo e($item->id); ?>">Detail</a>
                                                <a href="<?php echo e(route('admin.transactions.print.index', ['transaction' => $item->id])); ?>"
                                                    class="badge badge-primary" target="_blank">Cetak</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3">Transaksi Selesai</h4>
                            <table id="tbl-transaksi-selesai" class="table dt-responsive nowrap" style="width: 100%">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID Transaksi</th>
                                        <th>Tanggal</th>
                                        <th>Nama Member</th>
                                        <th>Status</th>
                                        <th>Biaya Service</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $finishedTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->member->name); ?></td>
                                            <td>
                                                <?php if($item->status_id == 3): ?>
                                                    <span class="text-success">Selesai</span>
                                                <?php else: ?>
                                                    <select name="" id="status" data-id="<?php echo e($item->id); ?>"
                                                        data-val="<?php echo e($item->status_id); ?>" class="select-status">
                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($item->status_id == $s->id): ?>
                                                                <option selected value="<?php echo e($s->id); ?>">
                                                                    <?php echo e($s->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->getFormattedServiceCost()); ?></td>
                                            <td><?php echo e($item->getFormattedTotal()); ?></td>
                                            <td>
                                                <a href="#" class="badge badge-info btn-detail" data-toggle="modal"
                                                    data-target="#transactionDetailModal"
                                                    data-id="<?php echo e($item->id); ?>">Detail</a>
                                                <a href="<?php echo e(route('admin.transactions.print.index', ['transaction' => $item->id])); ?>"
                                                    class="badge badge-primary" target="_blank">Cetak</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.modals.transaction-detail-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.modals.transaction-detail-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#tbl-transaksi-selesai').DataTable();
            $('#tbl-transaksi-belum').DataTable();
            $('#tbl-transaksi-priority').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XASMP\htdocs\app-laundry-crud\app-laundry-master\resources\views/admin/transactions_history.blade.php ENDPATH**/ ?>