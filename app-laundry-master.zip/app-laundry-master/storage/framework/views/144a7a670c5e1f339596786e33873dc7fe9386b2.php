<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="base_url" content="<?php echo e(url('admin')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Saran atau Komplain</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5>Daftar Saran atau Komplain</h5>
                            <div class="row">
                                <div class="col-sm-6">

                                    <table class="table">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Nama</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="bg-warning">
                                                    <td><?php echo e($complaint->user->name); ?></td>
                                                    <td><button href="#" class="badge badge-info lihat-isi"
                                                            data-id="<?php echo e($complaint->id); ?>">Lihat isi
                                                            komplain</button></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suggestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($suggestion->user->name); ?></td>
                                                    <td><button href="#" class="badge badge-info lihat-isi"
                                                            data-id="<?php echo e($suggestion->id); ?>">Lihat isi
                                                            saran</button></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <hr>
                                            <tr class="text-center">
                                                <td>Jumlah</td>
                                                <td><?php echo e($count); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="isi-aduan">Isi Aduan</label>
                                        <textarea class="form-control" id="isi-aduan" rows="3" disabled></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="balas">Balas</label>
                                        <textarea class="form-control" id="balas" rows="3" disabled></textarea>
                                    </div>
                                    <button id="btn-kirim-balasan" class="btn btn-primary" data-id="">Kirim</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ajax-saran.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XASMP\htdocs\app-laundry-crud\app-laundry-master\resources\views/admin/complaint_suggestion.blade.php ENDPATH**/ ?>