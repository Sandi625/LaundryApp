<?php $__env->startSection('main-content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard Member</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-10">
                                    <img class="img-circle img-fit float-left" width="100" height="100"
                                        src="<?php echo e($user->getFileAsset()); ?>" alt="Foto Profil">
                                    <div class="member-content">
                                        <h2 class="m-0"><?php echo e($user->name); ?></h2>
                                        <p class="small m-0">ID Member: <?php echo e($user->id); ?></p>
                                        <a href="<?php echo e(route('profile.index')); ?>" class="badge badge-primary badge-pill">Edit
                                            Profil</a>
                                    </div>
                                </div>
                                <div class="col-2 text-center">
                                    <p class="small m-0">Poin</p>
                                    <h2 class="m-0"><?php echo e($user->point); ?></h2>
                                    <a href="<?php echo e(route('member.points.index')); ?>"
                                        class="badge badge-primary badge-pill">Tukar
                                        Poin</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="my-3 text-center">Transaksi Terakhir</h3>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $latestTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                                            <td>
                                                <?php if($item->status_id != '3'): ?>
                                                    <span class="text-warning"><?php echo e($item->status->name); ?></span>
                                                <?php else: ?>
                                                    <span class="text-success"><?php echo e($item->status->name); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('member.transactions.show', ['transaction' => $item->id])); ?>"
                                                    class="badge badge-primary">Lihat Detail ></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app-laundry-master\resources\views/member/index.blade.php ENDPATH**/ ?>