<?php

return [
    'langtext' => 'Language',
    'welcome' => 'Welcome to ' . config('app.name'),
    'loginOrRegister' => 'Login / Register',
    'tagline' => 'Feel the best experience in laundry service',
    'why' => 'Why choose our laundry service?'
];
