<?php

return [
    'langtext' => 'Bahasa',
    'welcome' => 'Selamat datang di ' . config('app.name'),
    'loginOrRegister' => 'Masuk / Daftar',
    'tagline' => 'Dapatkan pengalaman terbaik dalam layanan laundry',
    'why' => 'Kenapa memilih layanan laundry kami?'
];
